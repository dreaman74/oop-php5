<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
	<title>Untitled</title>
</head>

<body>

<?php
	class io
		{
			  const NL="<br />";
					
					static public function linea($carattere, $quanti)
					{ return str_repeat($carattere, $quanti);}
					
					static public function saltaRighe($quanti)
					{ echo str_repeat(self::NL, $quanti); }
		}

  class Dado
		{
			 private $valoreAttuale=0, $numeroFacce=6,
				        $facciaTruccata=0, $quantoTruccata=0 ;
			
				public function __construct($numeroFacce)
				{ if($numeroFacce>0) $this->numeroFacce=$numeroFacce;}
			
			 public function setFacciaTruccata_Trucco($faccia, $trucco)
				{if ($faccia>0 && $faccia<$this->numeroFacce && $trucco>0)
				   $this->facciaTruccata = $faccia; $this->quantoTruccata = $trucco;}
				
			 public function lancia()
				{
					  $this->valoreAttuale = rand(1, $this->numeroFacce + $this->quantoTruccata);

					  if ($this->facciaTruccata>0  && $this->valoreAttuale>$this->numeroFacce)
							  $this->valoreAttuale = $this->facciaTruccata;
           							  
							return $this->valoreAttuale;
				}
				
				public function getValore()
				{return $this->valoreAttuale;}
		}
		
		
		$unDado = new Dado(6);
		$unDado->setFacciaTruccata_Trucco(4,5);
		
		for($lanci=1;$lanci<100;$lanci++)
		  echo $unDado->lancia().io::NL;
?>














</body>
</html>
